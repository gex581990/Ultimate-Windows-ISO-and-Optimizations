winget import -i $PSScriptRoot\ packages.json

Read-Host -Prompt "Press Enter to exit"